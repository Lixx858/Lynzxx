const intro=document.getElementById("intro"),app=document.getElementById("app"),bar=document.getElementById("progress"),dots=document.getElementById("dots");
let p=0;let iv=setInterval(()=>{p+=Math.random()*5+2;if(p>=100){p=100;clearInterval(iv);setTimeout(()=>{intro.style.transition="opacity .5s";intro.style.opacity=0;setTimeout(()=>{intro.remove();app.classList.remove("hidden")},520)},180)}bar.style.width=p+"%"},70);
let dc=0;setInterval(()=>{dc=(dc+1)%4;dots.textContent=".".repeat(dc||3)},300);

const drop=document.getElementById("drop"),file=document.getElementById("file"),picked=document.getElementById("picked"),btn=document.getElementById("deployBtn");let selected;
drop.onclick=()=>file.click();file.onchange=()=>pick(file.files[0]);
["dragenter","dragover"].forEach(x=>drop.addEventListener(x,e=>{e.preventDefault();drop.classList.add("drag")}));
["dragleave","drop"].forEach(x=>drop.addEventListener(x,e=>{e.preventDefault();drop.classList.remove("drag")}));
drop.addEventListener("drop",e=>pick(e.dataTransfer.files[0]));
function pick(f){if(!f)return;if(!/\.(html?|zip)$/i.test(f.name))return toast("FORMAT HARUS HTML/ZIP");selected=f;picked.textContent="✓ "+f.name;btn.disabled=false;log("Berkas dipilih: "+f.name,"ok")}

function log(s,c=""){let t=new Date().toLocaleTimeString("id-ID",{hour12:false});document.getElementById("log").innerHTML+=`\n<span class="muted">[${t}]</span> <span class="${c}">●</span> ${esc(s)}`;document.getElementById("log").scrollTop=999999}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function cleanName(s){return (s.trim()||"felix-project").toLowerCase().replace(/[^a-z0-9-]/g,"-").replace(/-+/g,"-").replace(/^-|-$/g,"").slice(0,48)}

btn.onclick=async()=>{
 const token=document.getElementById("token").value.trim(),name=cleanName(document.getElementById("name").value);
 if(!token)return toast("MASUKKAN VERCEL TOKEN");
 if(!selected)return;
 btn.disabled=true;log("Membaca berkas...");
 try{
   const files=await makeFiles(selected);
   log(`${files.length} file siap dikirim.`);
   log("Menghubungi Vercel API...");
   const res=await fetch("/api/deploy",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token,name,files})});
   const data=await res.json();
   if(!res.ok)throw new Error(data.error||"Deployment gagal");
   log("Deployment berhasil: "+data.url,"ok");
   saveProject({name,url:data.url,date:new Date().toLocaleDateString("id-ID")});
   render();toast("DEPLOY BERHASIL ✓");
   setTimeout(()=>window.open(data.url,"_blank"),500);
 }catch(e){log(e.message,"err");toast("DEPLOY GAGAL");}
 btn.disabled=false;
};

async function makeFiles(f){
 if(/\.zip$/i.test(f.name)){
   const z=await JSZip.loadAsync(f),out=[];
   for(const [path,obj] of Object.entries(z.files)){if(obj.dir)continue;if(path.includes("__MACOSX"))continue;
     const bytes=await obj.async("uint8array");out.push({file:normalizeZipPath(path),data:bytesToBase64(bytes)});
   }
   return out;
 }
 const bytes=new Uint8Array(await f.arrayBuffer());return [{file:f.name.toLowerCase()==="index.html"?"index.html":f.name,data:bytesToBase64(bytes)}];
}
function normalizeZipPath(p){p=p.replace(/^\/+/,"");let parts=p.split("/");if(parts.length>1&&/^package$/i.test(parts[0]))parts.shift();return parts.join("/")}
function bytesToBase64(bytes){let s="";const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)s+=String.fromCharCode(...bytes.subarray(i,i+chunk));return btoa(s)}

function get(){return JSON.parse(localStorage.getItem("felixdeploy_projects")||"[]")}
function saveProject(x){let a=get().filter(p=>p.name!==x.name);a.unshift(x);localStorage.setItem("felixdeploy_projects",JSON.stringify(a.slice(0,20)))}
function render(){let l=document.getElementById("list"),a=get();if(!a.length){l.innerHTML='<div class="empty">BELUM ADA PROJECT BERHASIL</div>';return}l.innerHTML=a.map((p,i)=>`<div class="project"><div><div class="pname">${esc(p.name)}</div><div class="date">Updated: ${p.date}</div></div><div class="actions"><button onclick="window.open('${esc(p.url)}','_blank')">◦ DOMAIN</button><button class="del" onclick="del(${i})">DELETE</button></div></div>`).join("")}
function del(i){let a=get();a.splice(i,1);localStorage.setItem("felixdeploy_projects",JSON.stringify(a));render();toast("PROJECT DIHAPUS")}
window.del=del;
function toast(s){let t=document.getElementById("toast");t.textContent=s;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
document.getElementById("reload").onclick=render;
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{document.querySelectorAll("nav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.getElementById(b.dataset.go).scrollIntoView({behavior:"smooth"})});
render();
