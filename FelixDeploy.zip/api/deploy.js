const { URL } = require("url");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const { token, name, files } = req.body || {};
    if (!token) return res.status(400).json({ error: "Vercel token wajib diisi." });
    if (!name || !/^[a-z0-9][a-z0-9-]*$/.test(name)) return res.status(400).json({ error: "Nama project tidak valid." });
    if (!Array.isArray(files) || !files.length) return res.status(400).json({ error: "Tidak ada file." });
    if (files.length > 1000) return res.status(400).json({ error: "Terlalu banyak file." });

    // Vercel Deployment API accepts file contents as base64.
    const payload = {
      name,
      files: files.map(x => ({
        file: String(x.file).replace(/^\/+/, ""),
        data: String(x.data),
        encoding: "base64"
      })),
      projectSettings: { framework: null }
    };

    const r = await fetch("https://api.vercel.com/v13/deployments", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const text = await r.text();
    let data;
    try { data = JSON.parse(text); } catch { data = {}; }

    if (!r.ok) {
      const msg = data.error?.message || data.message || `Vercel API error (${r.status})`;
      return res.status(r.status).json({ error: msg });
    }

    const url = data.url ? `https://${data.url}` : null;
    if (!url) return res.status(502).json({ error: "Vercel tidak mengembalikan URL deployment." });

    return res.status(200).json({ url, id: data.id });
  } catch (e) {
    return res.status(500).json({ error: e.message || "Server error" });
  }
};
