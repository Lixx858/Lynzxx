# FelixDeploy — Real Vercel Deployer

Ini adalah web deployer yang benar-benar memanggil Vercel Deployment API.

## Cara memakai
1. Deploy project FelixDeploy ini ke akun Vercel kamu.
2. Buat Vercel Personal Access Token dari dashboard Vercel.
3. Buka FelixDeploy.
4. Masukkan nama project, token, lalu pilih `.html` atau `.zip`.
5. Tekan **JALANKAN DEPLOYMENT**.
6. Web akan mengirim file ke Vercel dan membuka URL `https://namaproject-....vercel.app`.

Token tidak disimpan di localStorage dan hanya dikirim ke `/api/deploy` saat tombol deploy ditekan.

## Penting
- Jangan menaruh token Vercel di source code frontend.
- Untuk ZIP, isi ZIP diekstrak di browser lalu dikirim sebagai base64. Karena batas request/serverless Vercel, gunakan project yang ukurannya tidak terlalu besar.
- Untuk project besar, arsitektur sebaiknya memakai Vercel Blob atau storage sementara.
- Jika nama project sudah dipakai atau tidak tersedia, Vercel API akan mengembalikan error.

## Deploy FelixDeploy
Project ini adalah aplikasi Vercel dengan satu serverless function di `api/deploy.js`. Tidak perlu database.
